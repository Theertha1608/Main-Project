﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     db_giveandgrin
# Server version:               5.0.51b-community-nt
# Server OS:                    Win32
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2023-05-15 10:37:09
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'db_giveandgrin'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "db_giveandgrin" /*!40100 DEFAULT CHARACTER SET latin1 */;

USE "db_giveandgrin";


#
# Table structure for table 'tbn_admin'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_admin" (
  "admin_id" int(10) unsigned NOT NULL auto_increment,
  "admin_name" varchar(50) default NULL,
  "admin_email" varchar(50) default NULL,
  "admin_password" varchar(20) default NULL,
  PRIMARY KEY  ("admin_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbn_admin'
#

LOCK TABLES "tbn_admin" WRITE;
/*!40000 ALTER TABLE "tbn_admin" DISABLE KEYS;*/
REPLACE INTO "tbn_admin" ("admin_id", "admin_name", "admin_email", "admin_password") VALUES
	('1','theertha','theertha@gmail.com','123');
/*!40000 ALTER TABLE "tbn_admin" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_agency'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_agency" (
  "agency_id" int(10) unsigned NOT NULL auto_increment,
  "agency_name" varchar(50) default NULL,
  "agency_contact" varchar(50) default NULL,
  "agency_address" varchar(50) default NULL,
  "agency_email" varchar(50) default NULL,
  "agency_logo" varchar(50) default NULL,
  "agency_proof" varchar(50) default NULL,
  "place_id" int(10) unsigned default NULL,
  "agency_password" varchar(50) default NULL,
  "agency_vstatus" varchar(50) default '0',
  PRIMARY KEY  ("agency_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbn_agency'
#

LOCK TABLES "tbn_agency" WRITE;
/*!40000 ALTER TABLE "tbn_agency" DISABLE KEYS;*/
REPLACE INTO "tbn_agency" ("agency_id", "agency_name", "agency_contact", "agency_address", "agency_email", "agency_logo", "agency_proof", "place_id", "agency_password", "agency_vstatus") VALUES
	('1','Agency','8982897835','Plaza Building,Kannur','agency@gmail.com','Agency_1082.png','Agency_1776.png','17','agency','1');
/*!40000 ALTER TABLE "tbn_agency" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_category'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_category" (
  "category_id" int(10) unsigned NOT NULL auto_increment,
  "category_name" varchar(50) default NULL,
  PRIMARY KEY  ("category_id")
) AUTO_INCREMENT=17;



#
# Dumping data for table 'tbn_category'
#

LOCK TABLES "tbn_category" WRITE;
/*!40000 ALTER TABLE "tbn_category" DISABLE KEYS;*/
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('9','Single Person');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('10','Hospital');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('11','Multi-National-Companies');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('12','Charity Club');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('13','School');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('14','College');
REPLACE INTO "tbn_category" ("category_id", "category_name") VALUES
	('16','Others');
/*!40000 ALTER TABLE "tbn_category" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_complaint'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_complaint" (
  "complaint_id" int(10) unsigned NOT NULL auto_increment,
  "complaint_date" date default NULL,
  "complaint_description" varchar(250) default NULL,
  "complaint_status" varchar(50) default '0',
  "complaint_reply" varchar(150) default '0',
  "user_id" int(10) unsigned default NULL,
  "agency_id" int(10) unsigned default NULL,
  "donor_id" int(10) unsigned default NULL,
  PRIMARY KEY  ("complaint_id")
) AUTO_INCREMENT=15;



#
# Dumping data for table 'tbn_complaint'
#

LOCK TABLES "tbn_complaint" WRITE;
/*!40000 ALTER TABLE "tbn_complaint" DISABLE KEYS;*/
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('1',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('2',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('5','2023-03-22','help me','0','donor reply1',NULL,NULL,'8');
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('6','2023-03-22','help me','0','user reply1','2',NULL,NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('8','2023-03-22','help','0','agency reply 1',NULL,'1',NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('9','2023-03-22','im User complaint','0','user reply2','3',NULL,NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('11','2023-03-22','Im Donor Complaint','0','Donor reply2',NULL,NULL,'9');
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('13','2023-03-22','im agency complaint ','0','agency reply 2',NULL,'2',NULL);
REPLACE INTO "tbn_complaint" ("complaint_id", "complaint_date", "complaint_description", "complaint_status", "complaint_reply", "user_id", "agency_id", "donor_id") VALUES
	('14','2023-04-24','Bad experience','0','0','3',NULL,NULL);
/*!40000 ALTER TABLE "tbn_complaint" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_district'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_district" (
  "district_id" int(10) unsigned NOT NULL auto_increment,
  "district_name" varchar(50) default NULL,
  PRIMARY KEY  ("district_id")
) AUTO_INCREMENT=20;



#
# Dumping data for table 'tbn_district'
#

LOCK TABLES "tbn_district" WRITE;
/*!40000 ALTER TABLE "tbn_district" DISABLE KEYS;*/
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('7','Idukki');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('8','Ernakulam');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('9','Kannur');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('12','Malappuram');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('13','Trissur');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('14','Kollam');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('15','Calicut');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('16','Kasargod');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('17','Thiruvanadhapuram');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('18','Wayanad');
REPLACE INTO "tbn_district" ("district_id", "district_name") VALUES
	('19','Alappuzha');
/*!40000 ALTER TABLE "tbn_district" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_donation'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_donation" (
  "donation_id" int(10) unsigned NOT NULL auto_increment,
  "agency_id" int(10) unsigned default NULL,
  "donor_id" int(10) unsigned default NULL,
  "donation_amount" varchar(50) default NULL,
  "donation_date" date default NULL,
  "payment_status" varchar(50) default '0',
  PRIMARY KEY  ("donation_id")
) AUTO_INCREMENT=10;



#
# Dumping data for table 'tbn_donation'
#

LOCK TABLES "tbn_donation" WRITE;
/*!40000 ALTER TABLE "tbn_donation" DISABLE KEYS;*/
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('1','1','5','1000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('2','2','7','3000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('3','1','8','50000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('4','1','8','7000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('5','1','6','10000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('6','1','7','19000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('7','1','8','45000','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('8','1','8','20','2023-03-16','1');
REPLACE INTO "tbn_donation" ("donation_id", "agency_id", "donor_id", "donation_amount", "donation_date", "payment_status") VALUES
	('9','2','8','67000','2023-03-16','1');
/*!40000 ALTER TABLE "tbn_donation" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_donor'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_donor" (
  "donor_id" int(10) unsigned NOT NULL auto_increment,
  "donor_name" varchar(50) default NULL,
  "donor_contact" varchar(50) default NULL,
  "donor_address" varchar(200) default NULL,
  "donor_email" varchar(50) default NULL,
  "donor_photo" varchar(50) default NULL,
  "category_id" int(10) unsigned default NULL,
  "place_id" int(10) unsigned default NULL,
  "donor_password" varchar(50) default NULL,
  "donor_vstatus" varchar(50) default '0',
  PRIMARY KEY  ("donor_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbn_donor'
#

LOCK TABLES "tbn_donor" WRITE;
/*!40000 ALTER TABLE "tbn_donor" DISABLE KEYS;*/
REPLACE INTO "tbn_donor" ("donor_id", "donor_name", "donor_contact", "donor_address", "donor_email", "donor_photo", "category_id", "place_id", "donor_password", "donor_vstatus") VALUES
	('1','Donor','8756345690','Donor house','donor@gmail.com','Donor_1514.jpg','9','17','donor','1');
/*!40000 ALTER TABLE "tbn_donor" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_feedback'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_feedback" (
  "feedback_id" int(10) unsigned NOT NULL auto_increment,
  "user_id" int(10) unsigned default NULL,
  "agency_id" int(10) unsigned default NULL,
  "donor_id" int(10) unsigned default NULL,
  "feedback_description" varchar(50) default NULL,
  "feedback_date" date default NULL,
  PRIMARY KEY  ("feedback_id")
) AUTO_INCREMENT=5;



#
# Dumping data for table 'tbn_feedback'
#

LOCK TABLES "tbn_feedback" WRITE;
/*!40000 ALTER TABLE "tbn_feedback" DISABLE KEYS;*/
REPLACE INTO "tbn_feedback" ("feedback_id", "user_id", "agency_id", "donor_id", "feedback_description", "feedback_date") VALUES
	('1','3',NULL,NULL,'better','2023-03-22');
REPLACE INTO "tbn_feedback" ("feedback_id", "user_id", "agency_id", "donor_id", "feedback_description", "feedback_date") VALUES
	('2',NULL,NULL,'3','donor feedback','2023-03-22');
REPLACE INTO "tbn_feedback" ("feedback_id", "user_id", "agency_id", "donor_id", "feedback_description", "feedback_date") VALUES
	('3',NULL,'3',NULL,'agency feedback','2023-03-22');
REPLACE INTO "tbn_feedback" ("feedback_id", "user_id", "agency_id", "donor_id", "feedback_description", "feedback_date") VALUES
	('4',NULL,'3',NULL,'nice','2023-03-22');
/*!40000 ALTER TABLE "tbn_feedback" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_fundcategory'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_fundcategory" (
  "fundcategory_id" int(30) unsigned NOT NULL auto_increment,
  "fundcategory_name" varchar(50) default NULL,
  PRIMARY KEY  ("fundcategory_id")
) AUTO_INCREMENT=7;



#
# Dumping data for table 'tbn_fundcategory'
#

LOCK TABLES "tbn_fundcategory" WRITE;
/*!40000 ALTER TABLE "tbn_fundcategory" DISABLE KEYS;*/
REPLACE INTO "tbn_fundcategory" ("fundcategory_id", "fundcategory_name") VALUES
	('2','cash');
REPLACE INTO "tbn_fundcategory" ("fundcategory_id", "fundcategory_name") VALUES
	('3','bitcoin');
REPLACE INTO "tbn_fundcategory" ("fundcategory_id", "fundcategory_name") VALUES
	('4','cash1');
REPLACE INTO "tbn_fundcategory" ("fundcategory_id", "fundcategory_name") VALUES
	('5','cash1');
REPLACE INTO "tbn_fundcategory" ("fundcategory_id", "fundcategory_name") VALUES
	('6','cash1');
/*!40000 ALTER TABLE "tbn_fundcategory" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_fundreq'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_fundreq" (
  "fundreq_id" int(30) unsigned NOT NULL auto_increment,
  "fundreq_details" varchar(200) default NULL,
  "fundreq_amount" varchar(50) default NULL,
  "fundcategory_id" int(10) unsigned default NULL,
  "fundreq_proof" varchar(150) default NULL,
  "fundreq_date" date default NULL,
  "fundreq_vstatus" varchar(50) default '0',
  "user_id" int(10) unsigned default NULL,
  PRIMARY KEY  ("fundreq_id")
) AUTO_INCREMENT=9;



#
# Dumping data for table 'tbn_fundreq'
#

LOCK TABLES "tbn_fundreq" WRITE;
/*!40000 ALTER TABLE "tbn_fundreq" DISABLE KEYS;*/
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('1','accident','50000','2','Product_1084.jpg',NULL,'0',NULL);
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('2','accident','60000','2','Product_1910.jpeg','2023-03-15','0',NULL);
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('3','akhila nazrin','89786756','4','Product_1743.jpg','2023-03-15','0',NULL);
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('4','dfghjkl','1000000','2','Fund_1689.jpeg','2023-03-15','0','8');
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('5','Hospital Case','8000','2','Fund_2056.jpg','2023-03-15','1','1');
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('6','Hospital Case2','60000','4','Fund_2067.webp','2023-03-15','1','11');
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('7','accident','9000','2','Fund_1484.webp','2023-03-16','-1','1');
REPLACE INTO "tbn_fundreq" ("fundreq_id", "fundreq_details", "fundreq_amount", "fundcategory_id", "fundreq_proof", "fundreq_date", "fundreq_vstatus", "user_id") VALUES
	('8','accident case','10000','4','Fund_2051.jpeg','2023-03-16','1','1');
/*!40000 ALTER TABLE "tbn_fundreq" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_place'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_place" (
  "place_id" int(10) unsigned NOT NULL auto_increment,
  "place_name" varchar(50) default NULL,
  "place_pincode" int(50) default NULL,
  "district_id" int(10) unsigned default NULL,
  PRIMARY KEY  ("place_id")
) AUTO_INCREMENT=33;



#
# Dumping data for table 'tbn_place'
#

LOCK TABLES "tbn_place" WRITE;
/*!40000 ALTER TABLE "tbn_place" DISABLE KEYS;*/
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('5','Palayam',567432,'10');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('6','Kalpatta',890234,'11');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('7','Ponmudi',785674,'10');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('23','Kuttippuram',675412,'12');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('24','Vengad',690654,'9');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('25','Munnar',685647,'7');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('26','Cherthala',650890,'19');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('27','Kothamangalam',654654,'8');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('28','Perumbavoor',645897,'8');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('30','Kakkanad',654123,'8');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('31','Thalassery',653890,'9');
REPLACE INTO "tbn_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('32','Kunnamkulam',678902,'13');
/*!40000 ALTER TABLE "tbn_place" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_product'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_product" (
  "subcategory_id" int(10) unsigned default NULL,
  "product_id" int(10) unsigned NOT NULL auto_increment,
  "product_name" varchar(50) default NULL,
  "product_price" varchar(50) default NULL,
  "product_details" varchar(100) default NULL,
  "product_image" varchar(150) default NULL,
  PRIMARY KEY  ("product_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbn_product'
#

LOCK TABLES "tbn_product" WRITE;
/*!40000 ALTER TABLE "tbn_product" DISABLE KEYS;*/
REPLACE INTO "tbn_product" ("subcategory_id", "product_id", "product_name", "product_price", "product_details", "product_image") VALUES
	('8','1','hairband','800','good','Product_1118.webp');
/*!40000 ALTER TABLE "tbn_product" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_subcategory'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_subcategory" (
  "category_id" int(10) unsigned default NULL,
  "subcategory_id" int(10) unsigned NOT NULL auto_increment,
  "subcategory_name" varchar(50) default NULL,
  PRIMARY KEY  ("subcategory_id")
) AUTO_INCREMENT=15;



#
# Dumping data for table 'tbn_subcategory'
#

LOCK TABLES "tbn_subcategory" WRITE;
/*!40000 ALTER TABLE "tbn_subcategory" DISABLE KEYS;*/
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('3','9','subcategory1.2');
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('3','10','subcategory1.3');
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('4','11','subcategory2.1');
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('4','12','subcategory2.2');
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('5','13','subcategory3.1');
REPLACE INTO "tbn_subcategory" ("category_id", "subcategory_id", "subcategory_name") VALUES
	('5','14','subcategory3.2');
/*!40000 ALTER TABLE "tbn_subcategory" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbn_user'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbn_user" (
  "user_id" int(10) unsigned NOT NULL auto_increment,
  "user_name" varchar(50) default NULL,
  "user_dob" date default NULL,
  "user_contact" varchar(50) default NULL,
  "user_email" varchar(50) default NULL,
  "user_gender" varchar(50) default NULL,
  "place_id" int(10) unsigned default NULL,
  "user_photo" varchar(50) default NULL,
  "user_address" varchar(150) default NULL,
  "user_password" varchar(50) default NULL,
  "user_vstatus" varchar(50) default '0',
  PRIMARY KEY  ("user_id")
) AUTO_INCREMENT=6;



#
# Dumping data for table 'tbn_user'
#

LOCK TABLES "tbn_user" WRITE;
/*!40000 ALTER TABLE "tbn_user" DISABLE KEYS;*/
REPLACE INTO "tbn_user" ("user_id", "user_name", "user_dob", "user_contact", "user_email", "user_gender", "place_id", "user_photo", "user_address", "user_password", "user_vstatus") VALUES
	('1','jishna','2001-05-01','9876567890','jishna@gmail.com','Female','4','User_1367.jpeg','Jish Home','jish','1');
REPLACE INTO "tbn_user" ("user_id", "user_name", "user_dob", "user_contact", "user_email", "user_gender", "place_id", "user_photo", "user_address", "user_password", "user_vstatus") VALUES
	('2','Akhila','2000-05-09','7867564565','akhi@gmail.com','Female','3','User_1790.jpg','Akila house','akhi','1');
REPLACE INTO "tbn_user" ("user_id", "user_name", "user_dob", "user_contact", "user_email", "user_gender", "place_id", "user_photo", "user_address", "user_password", "user_vstatus") VALUES
	('3','User','2000-02-27','9747137525','user@gmail.com','Male','23','User_1440.jpg','Skyline Building ','user','1');
REPLACE INTO "tbn_user" ("user_id", "user_name", "user_dob", "user_contact", "user_email", "user_gender", "place_id", "user_photo", "user_address", "user_password", "user_vstatus") VALUES
	('4','Nila','2000-08-11','8289975752','nila@gmail.com','Female','1','User_1727.jpeg','Nila House Thodupuzha','nila','0');
REPLACE INTO "tbn_user" ("user_id", "user_name", "user_dob", "user_contact", "user_email", "user_gender", "place_id", "user_photo", "user_address", "user_password", "user_vstatus") VALUES
	('5','Hima','2000-05-12','8900347915','hima@gmail.com','Female','3','User_1411.jpg','Hima nivas','hima','0');
/*!40000 ALTER TABLE "tbn_user" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
